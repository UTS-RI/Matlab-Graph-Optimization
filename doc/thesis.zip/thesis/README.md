#UTS-CAS PhD Thesis template for \Latex.

Please note that this is __NOT__ an official template from UTS. UTS library doesn't support \Latex.

__Provided with no warranty. Use at your own risk.__

Please feel free to add/change/modify/refine and issue a pull-request so we all can benefit from those changes.

  *  Original by Gavin Paul.
  *  Modified by Phillip Quin.
  * Further refined by Lakshitha Dantanarayana
    * Change log:
      * Declaration of Authorship Changed to the new version required by GRS
      * Title commands are now in the main tex file not the class file
      *  New UTS logo added. 

(Official UTS logo guidelines dictate the logo should be where it is. Do not change position. Furthermore, the logo can only be used when the thesis is officially accepted by the university i.e. Final version. You might have to remove it if you plan to make intermediate versions public. E.g. In your website. Please check UTS policies.) 

